function X_best = unif_constr_best40()

p = 1; % rectangular distance (Manhattan norm), faster
% p = 2; % Euclidean distance, slower

X_start = unif_constr40;
X_best = X_start;
improved = 1;

% If the total iteration number reaches 10,000, stop and output the current
% best design
for i = 1:10
    % If the current best best design keeps unchanged for 1,000 iterations,
    % stop and output the current best design
    if improved == 0
        break
    end

    improved = 0;
    for j = 1:1000
       X_new = unif_constr40;
       Mmplan = mm(X_best,X_new,p);
       if Mmplan == 2
           X_best = X_new;
           improved = 1;
       end
    end
end

end
