%%%%%% This script generates the "optimal" designs.
%%%%%% The optimality is defined to maximize the smallest distance between 
%%%%%% all pairs of points within a sampling plan (Morris and Mitchell 1995).
%%%%%% We take 40 design points, and the search process is not exhaustive 
%%%%%% and terminated up to certain substantial computing budget.
%%%%%% To be fair and comprehensive, we totally consider 40 sets of such 
%%%%%% "optimal" designs, which are obtained with different random seeds.


% constraint: x1>=5, x2>=61, x3>=5, x4>= 21; x1+x2+x3+x4<=111
% that is: the biggest value for each x is the lower bound + 19


clear, clc

addpath ./Search_Optimal_Designs
X_best40 = zeros(40,4,40);
for i = 1:40
    fprintf('Design points set: %d  \n',i);
    s_pseudo = RandStream('mt19937ar','Seed',i);
    RandStream.setGlobalStream(s_pseudo); 
    X_best40(:,:,i) = unif_constr_best40;    
end


% %%% generate the kriging observations for the 40 sets of design points
% Y40 = zeros(size(X_best40,1),1,size(X_best40,3));
% Vhat40 = zeros(size(X_best40,1),1,size(X_best40,3));
% for seti = 1:size(X_best40,3)
%     for i = 1:size(X_best40,1)
%         tic
%         [Y40(i,1,seti), Vhat40(i,1,seti)] = Dock(X_best40(i,:,seti),30);
%         toc
%     end
% end
% % average run time: 96s on MATLAB R2015a
% % Windows 7 Enterprise 64-bit Operating System
% % Interl Core i7-3770 CPU @ 3.40GHz, 8 GB RAM  


%%% Remark: to save time, simulate each dock independently, then compute the weighted average %%%
Dock1 = zeros(20,2);
Dock2 = zeros(20,2);
Dock3 = zeros(20,2);
Dock4 = zeros(20,2);

% Non stationary Poisson Arrival
% arrival rate/h, 00-01, 01-02, ..., 23-24   unit: number/hour
arrival_rate = ...
[16	11	13	3	4	7	22	40	9	6	3	6	7	6	6	19	22	27	7	22	20	26	15	16; ...
 41	41	39	35	28	39	31	59	61	63	65	56	63	65	64	71	64	75	52	56	65	56	53	43; ...
 2	0	1	1	0	1	3	3	1	18	14	12	19	17	25	15	15	6	7	5	19	8	3	4; ...
 65	56	67	55	59	46	30	24	21	13	15	9	12	9	10	15	21	27	30	43	44	42	52	66];

% distribution of service time, unit: hour
service_dist{1} = 'wblrnd(21.8, 1.3)/60';
service_dist{2} = '(7 + wblrnd(67.6, 1.5))/60';
service_dist{3} = '(7 + gamrnd(0.9, 25.7))/60';
service_dist{4} = '(7 + gamrnd(3.0, 9.4))/60';

% Note: normally, T=192; T0=120; simR=30. But for some points, the simulation
% effort is increased such that the estimated standard deviation of the 
% averaged simulation output is controlled around 1 minute.

%%%% Dock 1
i = 1;
s_pseudo = RandStream('mt19937ar','Seed',i);
RandStream.setGlobalStream(s_pseudo);  
QueuePra.arrival_rate = arrival_rate(i,:);
QueuePra.servicetimeRV = service_dist{i};
QueuePra.K = inf;
SimPra.seed = []; % suppress random seed, control the overall seed in the outer funtion
j = 0;
for x = 5:5+19
    tic
    QueuePra.s = x;
    if x == 5
        T=600; T0=240; simR=100; 
    else
        T=192; T0=120; simR=30;
    end        
    SimPra.T = T;
    SimPra.T0 = T0;
    SimPra.simR = simR;        
    Wait_record = Q_GGsK_FIFO_NS(SimPra, QueuePra);
    c = Wait_record(:,1)*60;  % unit from hour to min
    aveWait = mean(c);            
    aveWait_var = var(c)/length(c);     
    j = j+1;
    Dock1(j,:) = [aveWait, aveWait_var];    
    toc
end

%%%% Dock 2
i = 2;
s_pseudo = RandStream('mt19937ar','Seed',i);
RandStream.setGlobalStream(s_pseudo);  
QueuePra.arrival_rate = arrival_rate(i,:);
QueuePra.servicetimeRV = service_dist{i};
QueuePra.K = inf;
SimPra.seed = []; % suppress random seed, control the overall seed in the outer funtion
j = 0;
for x = 61:61+19
    tic    
    QueuePra.s = x;   
    if x == 61
        T=600; T0=240; simR=1500;
    elseif x == 62   
        T=600; T0=240; simR=150;
    elseif x == 63 || x == 64 || x == 65
        T=600; T0=240; simR=30;
    else
        T=192; T0=120; simR=30;
    end 
    SimPra.T = T;
    SimPra.T0 = T0;
    SimPra.simR = simR;        
    Wait_record = Q_GGsK_FIFO_NS(SimPra, QueuePra);
    c = Wait_record(:,1)*60;  % unit from hour to min
    aveWait = mean(c);            
    aveWait_var = var(c)/length(c);      
    j = j+1;
    Dock2(j,:) = [aveWait, aveWait_var];
    toc
end

%%%% Dock 3
i = 3;
s_pseudo = RandStream('mt19937ar','Seed',i);
RandStream.setGlobalStream(s_pseudo);  
QueuePra.arrival_rate = arrival_rate(i,:);
QueuePra.servicetimeRV = service_dist{i};
QueuePra.K = inf;
SimPra.seed = []; % suppress random seed, control the overall seed in the outer funtion
j = 0;
for x = 5:5+19
    tic
    QueuePra.s = x;
    
    if x == 5 || x == 6 || x == 7
        T=600; T0=240; simR=100; 
    else
        T=192; T0=120; simR=30;
    end    
    SimPra.T = T;
    SimPra.T0 = T0;
    SimPra.simR = simR;        
    Wait_record = Q_GGsK_FIFO_NS(SimPra, QueuePra);
    c = Wait_record(:,1)*60;  % unit from hour to min
    aveWait = mean(c);            
    aveWait_var = var(c)/length(c);       
    j = j+1;
    Dock3(j,:) = [aveWait, aveWait_var];
    toc
end

%%%% Dock 4
i = 4;
s_pseudo = RandStream('mt19937ar','Seed',i);
RandStream.setGlobalStream(s_pseudo);  
QueuePra.arrival_rate = arrival_rate(i,:);
QueuePra.servicetimeRV = service_dist{i};
QueuePra.K = inf;
SimPra.seed = []; % suppress random seed, control the overall seed in the outer funtion
j = 0;
for x = 21:21+19
    tic
    QueuePra.s = x;   
    if x == 21 || x == 22 || x == 23
        T=600; T0=240; simR=100; 
    else
        T=192; T0=120; simR=30;
    end        
    SimPra.T = T;
    SimPra.T0 = T0;
    SimPra.simR = simR;        
    Wait_record = Q_GGsK_FIFO_NS(SimPra, QueuePra);
    c = Wait_record(:,1)*60;  % unit from hour to min
    aveWait = mean(c);            
    aveWait_var = var(c)/length(c);      
    j = j+1;
    Dock4(j,:) = [aveWait, aveWait_var];
    toc
end

%%%% kriging observations for the 40 sets of design points
%%%% the weighted average of each dock
arrival = sum(arrival_rate,2);
Y40 = zeros(size(X_best40,1),1,size(X_best40,3));
Vhat40 = zeros(size(X_best40,1),1,size(X_best40,3));
for seti = 1:size(X_best40,3)    
    X = X_best40(:,:,seti);    
    for i = 1:size(X,1)      
        index = X(i,:) - [5 61 5 21] + 1;         
        Y40(i,1,seti) = [Dock1(index(1),1), Dock2(index(2),1), Dock3(index(3),1), Dock4(index(4),1)] ...
                        * arrival / sum(arrival);
        Vhat40(i,1,seti) = [Dock1(index(1),2), Dock2(index(2),2), Dock3(index(3),2), Dock4(index(4),2)] ...
                           * (arrival.^2) / sum(arrival)^2;
    end
end

