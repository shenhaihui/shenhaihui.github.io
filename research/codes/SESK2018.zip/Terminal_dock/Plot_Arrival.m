clear,clc,close all;

% Non stationary Poisson Arrival
% arrival rate/h, 00-01, 01-02, ..., 23-24   unit: number/hour
arrival_rate = ...
[16	11	13	3	4	7	22	40	9	6	3	6	7	6	6	19	22	27	7	22	20	26	15	16; ...
 41	41	39	35	28	39	31	59	61	63	65	56	63	65	64	71	64	75	52	56	65	56	53	43; ...
 2	0	1	1	0	1	3	3	1	18	14	12	19	17	25	15	15	6	7	5	19	8	3	4; ...
 65	56	67	55	59	46	30	24	21	13	15	9	12	9	10	15	21	27	30	43	44	42	52	66];

figure; hold on 
set (gcf,'Position',[500,500,520,350])
box on;

axis([0 24 0 85]);
xlabel('24 one-hour intervals               ','Interpreter','latex');
% ylabel('Arrival numbers / hour $\quad$','Interpreter','latex');
ylabel('Hourly arrival rates $\quad$','Interpreter','latex');
set(gca,'XTick',[1 4 8 12 16 20 24]);


%%% multi column legend, do it by hand 
plot(1:24,arrival_rate(1,:),'s-','LineWidth',1,'Color',[31,119,180]/255)
plot(1:24,arrival_rate(2,:),'o-','LineWidth',1,'Color',[255,127,14]/255)
ht = legend({'Cargo 1','Cargo 2'}); 
% legend boxoff 
set(ht,'Interpreter','latex','color','none','Location','northwest');

ph = plot(1:24,arrival_rate(3,:),'g^-',1:24,arrival_rate(4,:),'rx-','LineWidth',1);

ah=axes('position',get(gca,'position'),'visible','off');
ht2 = legend(ah,ph,{'Cargo 3','Cargo 4'},'Position',[.52,.845,0,0]);
% legend boxoff 
set(ht2,'Interpreter','latex','color','none');


% %%% save data, plot in python
% save('Dock_plot_arrival.mat','arrival_rate');

