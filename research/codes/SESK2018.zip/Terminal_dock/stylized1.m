% stylized model 1 - treat the system as M/M/s queue

function waiting_time = stylized1(s)   %%% weighted average waiting time

arrival_rate = [13.875 53.54166667 8.291666667 34.625];
lam = arrival_rate/60; % n/min

service_time_mean = [20.1340 68.0256 30.1300 35.2000];
mu = 1./service_time_mean;

sojourn = zeros(1,4);
for i=1:4
    % MMs Queue Waiting Time
    sojourn(i) = W_MMsK(s(i),mu(i),lam(i),inf) - 1/mu(i);
end

waiting_time = sojourn * lam' / sum(lam);
end

function W = W_MMsK(s,mu,lam,K) % sojune time in the station

rho = lam/(s*mu);
if K < inf
    L = L_MMsK(s,mu,lam,K);
    P_enter = 1-Dis_MMsK(K,s,mu,lam,K);
    W = L / (lam*P_enter);
else
    W = 1/mu + Dis_MMsK(s,s,mu,lam,K)/(s*mu)/(1-rho)^2;
    % or
    % L = L_MMsK(s,mu,lam,K);
    % W = L/lam;
end
end

function L = L_MMsK(s,mu,lam,K)  % expected number in the station

rho = lam/(s*mu);
if K < inf
    L = 0;
    for n=0:K
        L = L + Dis_MMsK(n,s,mu,lam,K)*n;
    end
else
    L = lam/mu + Dis_MMsK(s,s,mu,lam,K)*rho/(1-rho)^2;
end
end

function PPP = Dis_MMsK(n,s,mu,lam,K)

rho = lam/(s*mu);

P0 = 0;
for i = 0:s-1
    P0 = P0 + 1/factorial(i) * (lam/mu)^i;
end

if K < inf
    P0 = P0 + (lam/mu)^s/factorial(s)*sum(rho.^(0:K-s));
else
    P0 = P0 + (lam/mu)^s/factorial(s) / (1-rho);
end
P0 = 1/P0;

if n <= s-1
    PPP = P0 * 1/factorial(n) * (lam/mu)^n;
else
    PPP = P0 * s^s/factorial(s) * rho^n;
end
end

