clear; clc; close all;
addpath ../SKDec122009/SK_code_version1_1229;
addpath ..


kriging_type = 0;
% 0, Ordinary Stochastic Kriging (OSK)
% 1, Stylized-Model Enhanced Stochastic Kriging (SESK), stylized model 1
% 2, SESK, stylized model 2
% 3, SESK with ref1 + ref2


%%% Predicted points
% allocation of docks for type 1, 2, 3, 4 cargos
M = 111; x1L = 5; x2L = 61; x3L = 5; x4L = 21;
% the entire 8855 points in the feasible region are considered
i = 0;
XK = zeros(8855,4);
y_true = zeros(8855,1);
for x1 = x1L : M-x2L-x3L-x4L
    for x2 = x2L : M-x1-x3L-x4L
        for x3 = x3L : M-x1-x2-x4L
            for x4 = x4L : M-x1-x2-x3
                i = i+1;
                x = [x1 x2 x3 x4];               
                XK(i,:) = x;
            end
        end
    end
end
K = size(XK,1);

% load the "true" response value
% to see how it is obtained, see Generate_True_Waiting_Time.m
load('y_true.mat');


%%% Observed points
% load the 40 set of design points (each contains 40 points), and the noisy
% observations.
% to see how it is obtained, see Generate_Design_Points_and_Obs.m
load('X_best40.mat');
load('Y_Vhat40.mat');
seti = 18;  % one typical design
X = X_best40(:,:,seti);  
k = size(X,1);
Y = Y40(:,:,seti);    
Vhat = Vhat40(:,:,seti);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch (kriging_type)
    case 0 % OSK, constant trend term
        BK = ones(K,1);
        B = ones(k,1);

    case 1 % SESK, (with stylized model 1) 
        refK = zeros(K,1);
        for i=1:K
            x = XK(i,:);
            refK(i) = stylized1(x);
        end 
        
        % calculate RMSE MAPE if the stylized model 1 is directly used as prediction
        RMSE_stylized1 = sqrt(sum((refK - y_true).^2)/length(y_true));
        MAPE_stylized1 = sum(abs((refK - y_true) ./ y_true))/length(y_true);        
        
        ref = zeros(k,1);
        for i=1:k
            x = X(i,:);
            ref(i) = stylized1(x);
        end
        BK = [ones(K,1) refK];
        B = [ones(k,1) ref];

    case 2 % SESK, (with stylized model 2)
        refK = zeros(K,1);
        for i=1:K
            x = XK(i,:);
            refK(i) = stylized2(x);
        end     
        
        % calculate RMSE MAPE if the stylized model 2 is directly used as prediction
        RMSE_stylized2 = sqrt(sum((refK - y_true).^2)/length(y_true));
        MAPE_stylized2 = sum(abs((refK - y_true) ./ y_true))/length(y_true);        
        
        ref = zeros(k,1);
        for i=1:k
            x = X(i,:);
            ref(i) = stylized2(x);
        end
        BK = [ones(K,1) refK];
        B = [ones(k,1) ref];
        
    case 3 % SESK, (with stylized model 1&2)
        refK1 = zeros(K,1);
        for i=1:K
            x = XK(i,:);
            refK1(i) = stylized1(x);
        end 

        refK2 = zeros(K,1);
        for i=1:K
            x = XK(i,:);
            refK2(i) = stylized2(x);
        end     
        
        ref1 = zeros(k,1);
        ref2 = zeros(k,1);
        for i=1:k
            x = X(i,:);
            ref1(i) = stylized1(x);
            ref2(i) = stylized2(x);
        end
        BK = [ones(K,1) refK1 refK2];
        B = [ones(k,1) ref1 ref2];        
end


% === >>> SK fit and predict:
% stochastic kriging with constant trend (q=0), 
% gammaP correlation function, 1-exponential, 2-gauss, 3-cubic
gammaP = 2;
skriging_model = SKfit(X,Y,B,Vhat,gammaP);
SK  = SKpredict(skriging_model,XK,BK);
RMSE = sqrt(sum((SK - y_true).^2)/length(y_true));       % RMSE
MAPE = sum(abs((SK - y_true) ./ y_true))/length(y_true); % MAPE


%%%%%%%%% plot out one profile
%%% plot points
x1 = 6; x3 = 10; M = 111;
x2range = 62:74;
i = 0;
for x2 = x2range
    x = [x1 x2 x3 M-x1-x2-x3];
    row = find(ismember(XK,x,'rows'));
    i = i+1;
    yplot(i) = y_true(row);
    Xplot(i,:) = x;
end
Kplot = length(yplot);

%%% Observed points
i = 0;
for x2 = x2range
    x = [x1 x2 x3 M-x1-x2-x3];
    row = find(ismember(X,x,'rows'));
    if ~isempty(row)
        i = i+1;
        xobs(i) = x2;
        Yobs(i) = Y(row);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch (kriging_type)
    case 0 % OSK, constant trend term
        BKplot = ones(Kplot,1);

    case 1 % SESK, (with stylized model 1)         
        for i=1:Kplot
            x = Xplot(i,:);
            refKplot(i,1) = stylized1(x);
        end
        BKplot = [ones(Kplot,1) refKplot];

    case 2 % SESK, (with stylized model 2)
        for i=1:Kplot
            x = Xplot(i,:);
            refKplot(i,1) = stylized2(x);
        end 
        BKplot = [ones(Kplot,1) refKplot];
    case 3 % SESK, (with stylized model 1&2)
        for i=1:Kplot
            x = Xplot(i,:);
            refKplot1(i,1) = stylized1(x);
            refKplot2(i,1) = stylized2(x);
        end
        BKplot = [ones(Kplot,1) refKplot1, refKplot2];
end
[SKplot, MSEplot] = SKpredict(skriging_model,Xplot,BKplot);

% === >>> print parameters:
printSK (skriging_model);
fprintf('RMSE = %.3f; \n',RMSE);
fprintf('MAPE = %.5f; \n',MAPE);


% === >>> plot SK fitted surface:
figure;
set (gcf,'Position',[500,500,520,300])
plot(x2range,yplot,'*','LineWidth',1,'Color',[31,119,180]/255); hold on;
plot(xobs,Yobs,'o','Color',[255,127,14]/255);
plot(x2range,SKplot,'k--','LineWidth',1);
if kriging_type == 3
    plot(0,0,'w.');
end
% MSE
plot(x2range,SKplot+1.96*sqrt(MSEplot),':','LineWidth',0.8,'Color',[214,39,40]/255);
h1 = plot(x2range,SKplot-1.96*sqrt(MSEplot),':','LineWidth',0.8,'Color',[214,39,40]/255); 

% add ref
if kriging_type == 1 || kriging_type == 2
    plot(x2range,refKplot,'+','Color',[44,160,44]/255);
end

% figure format
axis([62 74 0 90]);
xlabel('$x_2$','Interpreter','latex');
ylabel('Mean waiting time (min.)','Interpreter','latex');
set(gca,'XTick',62:74)


set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
switch (kriging_type)
    case 0 % OSK, constant trend term
        ht = legend({'True response','Mean simulation output',...
            'Fitted surface of OSK','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
            },'Location','north'); %,'FontSize',11
    case 1 % SESK with stylized model 1
        ht = legend({'True response','Mean simulation output',...
            'Fitted surface of SESK','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
            'Stylized model 1'},'Location','north'); 
    case 2 % SESK with stylized model 2
        ht = legend({'True response','Mean simulation output',...
            'Fitted surface of SESK','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals'...
            'Stylized model 2'},'Location','north');
    case 3 % SESK with stylized model 1&2
        ht = legend({'True response','Mean simulation output',...
            'Fitted surface of SESK with','both stylized models','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
            },'Location','north'); 

end
set(ht,'Interpreter','latex','color','none');


% %%% save data, plot in python
% MSE_po = SKplot+1.96*sqrt(MSEplot);
% MSE_ne = SKplot-1.96*sqrt(MSEplot);
% x2range = x2range';
% yplot = yplot';
% % save('Dock_plot_0.mat','x2range','yplot','xobs','Yobs','SKplot','MSE_po','MSE_ne');
% % save('Dock_plot_2.mat','x2range','yplot','xobs','Yobs','SKplot','MSE_po','MSE_ne','refKplot');
% save('Dock_plot_3.mat','x2range','yplot','xobs','Yobs','SKplot','MSE_po','MSE_ne');
