%%%%%% This script generates the "true" waiting time through sufficiently longtime simulation
%%%%%% 95% conffidence interval width < 0.2 minute

clear, clc

% Non stationary Poisson Arrival
% arrival rate/h, 00-01, 01-02, ..., 23-24   unit: number/hour
arrival_rate = ... 
[16	11	13	3	4	7	22	40	9	6	3	6	7	6	6	19	22	27	7	22	20	26	15	16; ...
 41	41	39	35	28	39	31	59	61	63	65	56	63	65	64	71	64	75	52	56	65	56	53	43; ...
 2	0	1	1	0	1	3	3	1	18	14	12	19	17	25	15	15	6	7	5	19	8	3	4; ...
 65	56	67	55	59	46	30	24	21	13	15	9	12	9	10	15	21	27	30	43	44	42	52	66];
arrival = sum(arrival_rate,2);


% distribution of service time, unit: hour
service_dist{1} = 'wblrnd(21.8, 1.3)/60';
service_dist{2} = '(7 + wblrnd(67.6, 1.5))/60';
service_dist{3} = '(7 + gamrnd(0.9, 25.7))/60';
service_dist{4} = '(7 + gamrnd(3.0, 9.4))/60';


%%% Remark: to save time, simulate each dock independently, then compute the weighted average %%%

% One may use the function Q_GGsK_FIFO_NS.m to do so, just as in generating 
% the kriging observations.
% Or, a more efficient way is to utilize Arena (much faster!).
% The Arena model is given in ./Terminal Dock_Arena.
% Setting in Arena: Replications: 2000, Warm-up: 240h, Total Length: 600h

% The "true" waiting time for each dock is listed as follows:
% Dock1, server:5-24, waiting time
Dock1 = [...
108.7606, 38.5560, 16.0826, 7.7423, 4.2454, 2.4549, 1.4466, 0.8579, ...
0.5185, 0.3049, 0.1796, 0.1012, 0.0571, 0.0319, 0.0172, 0.0092, ...
0.0047, 0.0024, 0.0012, 0.0006];

% Dock2, server:61-80, waiting time
Dock2 = [...
153.0702, 80.8280, 60.1524, 49.1711, ...
41.1689, 34.2648, 28.3022, 23.0007, ...
18.7641, 14.9677, 11.7711, 9.2841, ...
7.2370, 5.6335, 4.3482, 3.3702, ...
2.6216, 2.0219, 1.5749, 1.2048];

% Dock3, server:5-24
Dock3 = [...
185.2802, 98.7831, 48.3650, 23.3439, 11.5898, 5.8837, 2.9898, 1.5395, ...
0.7974, 0.4097, 0.2119, 0.1080, 0.0550, 0.0276, 0.0138, 0.0063, ...
0.0029, 0.0014, 0.0007, 0.0003];

% Dock4, server:21-40, waiting time
Dock4 = [...
166.4943, 132.3454, 110.4326, 92.2054, 76.6177, 63.3333, 52.2644, 42.9874, ...
34.7844, 27.8040, 21.9717, 17.0573, 12.9004, 9.4192, 6.7694, 4.7089, ...
3.2327, 2.1811, 1.4678, 0.9880];


% compute the "true" waiting time for the system
M = 111; x1L = 5; x2L = 61; x3L = 5; x4L = 21;
i = 0;
% the entire 8855 points in the feasible region are considered
XK = zeros(8855,4);
y_true = zeros(8855,1);
for x1 = x1L : M-x2L-x3L-x4L
    for x2 = x2L : M-x1-x3L-x4L
        for x3 = x3L : M-x1-x2-x4L
            for x4 = x4L : M-x1-x2-x3
                i = i+1;
                x = [x1 x2 x3 x4];
                index = x - [x1L x2L x3L x4L] + 1;                
                y = [Dock1(index(1)), Dock2(index(2)), Dock3(index(3)), Dock4(index(4))] ...
                *arrival / sum(arrival);                
                XK(i,:) = x;
                y_true(i,1) = y;
            end
        end
    end
end

