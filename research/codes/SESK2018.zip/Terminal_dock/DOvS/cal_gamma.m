% calculate gamma
% input x1 x2 (can have more than 1 rows)

function gam = cal_gamma(x1,x2)
vec = x1-x2;
Ed = sum(vec.^2,2).^0.5;
gam = exp(-Ed.^0.5);
end