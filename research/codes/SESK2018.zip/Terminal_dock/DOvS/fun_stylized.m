function y = fun_stylized(x)

% minimize -> maximize
y = - stylized2(x);

end