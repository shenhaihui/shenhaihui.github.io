%%%%% construct sampling distribution and sample solution

function Sk = GPS_Sampling(SSk,g_star,x_star,s)

d = 4;   
% not cubic range
M = 111; x1L = 5; x2L = 61; x3L = 5; x4L = 21;
xL = [x1L x2L x3L x4L];

sigma = 15;  %variance for Gaussian process

xi = SSk(:,1:d);
nk = SSk(:,d+1);
G = SSk(:,d+2);
var_k = SSk(:,d+3);
SIGM = diag(var_k./nk);
m = size(xi,1);

% calculate GAMMA
GAM = zeros(m,m);   % only need half triangle (faster!)
for j = 1:m
    GAM(j:m,j) = cal_gamma(xi(j:m,:),repmat(xi(j,:),m-j+1,1));
end
GAM = GAM + GAM' - eye(m);

%%% Markov Chain Coordinate Sampling (MCCS)
T = 50;
Sk = zeros(s,d);
for i=1:s   %number of solutions sampled
    
    y = x_star;
    
    for t = 1:T
        % Sample Uniformly an interger I from 1 to d
        I = unidrnd(d);
        % Sample discrete j uniformly from [0,y(I)-0.1]u[y(I)+0.1,10]
        
        vL = xL(I);
        vH = M - (sum(y)-y(I));
        if vL == vH
            continue;
        end 
        
        j = y(I);
        while j == y(I)
            % j = unidrnd(coor_N)*coor_s;
            j = randi([vL, vH]);
        end
        z = y;
        z(I) = j;
        % use z or not?
        
        % calculate lam - input y,xi,   &   z,xi
        b=-4;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        x = y;
        % if x == one of xi, return 1 & 0
        if_menber = find(ismember(xi,x,'rows'));
        if isempty(if_menber) % x is not a member of xi
            vec = xi - repmat(x,m,1);
            vec = sum(vec.^2,2).^(0.5*b); 
            vec_sum = sum(vec);
            lam = vec/vec_sum;
        else
            lam = zeros(m,1);
            lam(if_menber) = 1;
        end

        % calculate gamma_x - input x,xi
        gam_x = cal_gamma(repmat(x,m,1),xi);

        % Y~N(E_Y,Var_Y)
        E_Y = lam'*G;             
        Var_Y = sigma^2*(1-2*lam'*gam_x+lam'*GAM*lam) + lam'*SIGM*lam;       
        P_Y_y = (1 - normcdf(g_star,E_Y,Var_Y^0.5));
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        x = z;
        % if x == one of xi, return 1 & 0
        if_menber = find(ismember(xi,x,'rows'));
        if isempty(if_menber) % x is not a member of xi
            vec = xi - repmat(x,m,1);
            vec = sum(vec.^2,2).^(0.5*b); 
            vec_sum = sum(vec);
            lam = vec/vec_sum;
        else
            lam = zeros(m,1);
            lam(if_menber) = 1;
        end

        % calculate gamma_x - input x,xi
        gam_x = cal_gamma(repmat(x,m,1),xi);

        % Y~N(E_Y,Var_Y)
        E_Y = lam'*G;
        Var_Y = sigma^2*(1-2*lam'*gam_x+lam'*GAM*lam) + lam'*SIGM*lam;       
        P_Y_z = (1 - normcdf(g_star,E_Y,Var_Y^0.5));        
        
        if rand <= P_Y_z/P_Y_y
            y = z;
        end
        
    end    
    Sk(i,:) = y;
end

end