%%%% Stylized-model Enhanced Gaussian Process-Based Search (SEGPS) Algorithm 

function Opti_Record = SEGPS()

d = 4;   
% not cubic range
M = 111; x1L = 5; x2L = 61; x3L = 5; x4L = 21;


s = 3;       %# of solutions sampled
r = 5;      %# of observations
var_LB = 0.5;

% ==== initializaiton ====
scale=1; shift=0;

% uniformly sample s
Sk = zeros(s,d);
for i=1:s
    x1 = randi([x1L, M-x2L-x3L-x4L]);
    x2 = randi([x2L, M-x1-x3L-x4L]);
    x3 = randi([x3L, M-x1-x2-x4L]);
    x4 = randi([x4L, M-x1-x2-x3]);
    Sk(i,:) = [x1 x2 x3 x4];
end
Sk = unique(Sk,'rows');  % remove the duplication

% take r observations
Gk = zeros(size(Sk,1),r);
Gk_s = zeros(size(Sk,1),1);
for si=1:size(Sk,1)
    for ri=1:r
       Gk(si,ri) = fun(Sk(si,:));       
    end
    Gk_s(si,1) = fun_stylized(Sk(si,:));
end

% calculate mean and variance
GGk = Gk;
SSk = Sk;
SSk(:,d+1) = ones(size(Sk,1),1)*r;  % # of observations
SSk(:,d+4) = Gk_s;                  % value of stylized fun
SSk(:,d+5) = mean(Gk,2);            % mean of original fun
SSk(:,d+2) = SSk(:,d+5) - (SSk(:,d+4)*scale+shift);  % mean of difference surface
SSk(:,d+3) = var(Gk,0,2);           % var of difference surface

% check the lower bound
% bound = SSk(:,d+2);
% bound(bound<mean_LB)=mean_LB;
% SSk(:,d+2) = bound;
bound = SSk(:,d+3);
bound(bound<var_LB) = var_LB;
SSk(:,d+3) = bound;

% current best
[g_star,max_location] = max(SSk(:,d+5));
x_star = SSk(max_location,1:d);

% keep record
step = 1;
fprintf('%d  [%.2f, %.2f, %.2f, %.2f] %.2f \n',step,x_star,g_star);
Opti_Record(1,:) = [x_star g_star];


% ==== iteration ====
while step < 30 %50
            
    % sample s from fitted distribution
    Sk = SEGPS_Sampling(SSk,g_star,x_star,s,scale,shift);

    % take r observations
    Gk = zeros(size(Sk,1),r);
    Gk_s = zeros(size(Sk,1),1);
    for si=1:size(Sk,1)
        for ri=1:r
           Gk(si,ri) = fun(Sk(si,:));       
        end
        Gk_s(si,1) = fun_stylized(Sk(si,:));
    end

    % merge to SSk GGk
    revisit = [];
    for i = 1:size(Sk,1)
        % check if there is duplication
        if_menber = find(ismember(SSk(:,1:d),Sk(i,:),'rows'));    
        if isempty(if_menber)
            % add into end of SSk GGk
            m = size(SSk,1);       
            GGk(m+1,1:r) = Gk(i,:);        
            SSk(m+1,1:d+1) = [Sk(i,:),r];            
            % add into SSk
            SSk(m+1,d+4) = Gk_s(i,1);            % mean of simple
            SSk(m+1,d+5) = mean(Gk(i,:));        % mean of hard              
            SSk(m+1,d+2) = SSk(m+1,d+5) - (SSk(m+1,d+4)*scale+shift);   % mean of difference surface
            SSk(m+1,d+3) = var(Gk(i,:));       % var of difference surface
        else
            nk = SSk(if_menber,d+1);        
            GGk(if_menber,nk+1:nk+r) = Gk(i,:);                 
            SSk(if_menber,d+1) = nk+r;
            % keep record of the revisit
            revisit = [revisit; if_menber];
        end
    end
    % update SSk
    if ~isempty(revisit)
        for j = 1:length(revisit)
            i = revisit(j);
            nk = SSk(i,d+1); 
            SSk(i,d+5) = mean(GGk(i,1:nk));   % mean of hard 
            SSk(i,d+2) = SSk(i,d+5) - (SSk(i,d+4)*scale+shift);   % mean of difference surface
            SSk(i,d+3) = var(GGk(i,1:nk));    % var of difference surface
        end
    end

    % check the lower bound
    % bound = SSk(:,d+2);
    % bound(bound<mean_LB)=mean_LB;
    % SSk(:,d+2) = bound;
    bound = SSk(:,d+3);
    bound(bound<var_LB) = var_LB;
    SSk(:,d+3) = bound;

    % current best
    [g_star,max_location] = max(SSk(:,d+5));
    x_star = SSk(max_location,1:d);

    % keep record
    step = step+1;
    fprintf('%d  [%.2f, %.2f, %.2f, %.2f] %.2f \n',step,x_star,g_star);
    Opti_Record(step,:) = [x_star g_star];

    % ==== update the scale, shift ====
    if mod(step,5) ==0
        Y = SSk(:,d+5);
        k = size(Y,1);
        g_x = SSk(:,d+4);
        Ys = [ones(k,1) g_x];
        be = (Ys'*Ys)^(-1)*Ys'*Y;
        shift = be(1);
        scale = be(2);
        
        % update the mean of difference surface
        SSk(:,d+2) = SSk(:,d+5) - (SSk(:,d+4)*scale+shift);
    end

end