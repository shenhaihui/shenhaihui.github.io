clear,clc, close all;
addpath ..

% % repeat GPS 40 times
% for i=1:40
%     seed = i
%     s_pseudo = RandStream('mt19937ar','Seed',seed);
%     RandStream.setGlobalStream(s_pseudo);            
%     Opti_Record = GPS;
%     GPS_Record(i,:) = Opti_Record(:,5)';
% end
% % repeat CGPS 40 times
% for i=1:40
%     seed = i
%     s_pseudo = RandStream('mt19937ar','Seed',seed);
%     RandStream.setGlobalStream(s_pseudo);    
%     Opti_Record = SEGPS;
%     SEGPS_Record(i,:) = Opti_Record(:,5)';
% end
% % total run time: about 1.5 day, on MATLAB R2015a
% % Windows 7 Enterprise 64-bit Operating System
% % Interl Core i7-3770 CPU @ 3.40GHz, 8 GB RAM

% this is the saved record
load('Record_GPS_SEGPS.mat')

figure;
set (gcf,'Position',[500,500,520,300])
x = 1:30;
% change (back) the maximization to minimization
plot(x*15,-mean(GPS_Record),'-','LineWidth',1,'Color',[31,119,180]/255); hold on;
plot(x*15,-mean(SEGPS_Record),'k--','LineWidth',1);
axis([0 450 25 60]);
xlabel('Total observations','Interpreter','latex');
ylabel('Estimated optimal value','Interpreter','latex');
ht = legend({'GPS','SEGPS'},'Location','north','Interpreter','latex');


% %%% save data, plot in python
% x = (x*15)';
% y1 = (-mean(GPS_Record))';
% y2 = (-mean(SEGPS_Record))';
% save('Dock_DOvS_plot.mat','x','y1','y2');