function [aveWait, aveWait_var] = Dock(s,simR)     
% ========================= function statement ============================
% Output
% aveWait - weighted average waiting time
% aveWait_var - variance of the weighted AVERAGED waiting time
% Input
% x - number of docks assigned to the cargo type 1 2 3 4
% simR - replication number
% =========================================================================


% Non stationary Poisson Arrival
% arrival rate/h, 00-01, 01-02, ..., 23-24   unit: number/hour
arrival_rate = ...
[16	11	13	3	4	7	22	40	9	6	3	6	7	6	6	19	22	27	7	22	20	26	15	16; ...
 41	41	39	35	28	39	31	59	61	63	65	56	63	65	64	71	64	75	52	56	65	56	53	43; ...
 2	0	1	1	0	1	3	3	1	18	14	12	19	17	25	15	15	6	7	5	19	8	3	4; ...
 65	56	67	55	59	46	30	24	21	13	15	9	12	9	10	15	21	27	30	43	44	42	52	66];

% distribution of service time, unit: hour
service_dist{1} = 'wblrnd(21.8, 1.3)/60';
service_dist{2} = '(7 + wblrnd(67.6, 1.5))/60';
service_dist{3} = '(7 + gamrnd(0.9, 25.7))/60';
service_dist{4} = '(7 + gamrnd(3.0, 9.4))/60';

% % 
% T=192; T0=120; 

% for 
% T=192; T0=120; simR=1;

T = 192; T0 = 120;
% simR = 30;  % for kriging. bias is large when on the boundary
% simR = 1;   % for DOvS



SimPra.seed = []; % suppress random seed, control the overall seed in the outer funtion
SimPra.T = T;
SimPra.T0 = T0;
SimPra.simR = simR;
QueuePra.K = inf;

Wait_record = zeros(simR,2,4);

% tic
for i=1:4
%     fprintf('station %d  \n',i);
    QueuePra.arrival_rate = arrival_rate(i,:);
    QueuePra.s = s(i);
    QueuePra.servicetimeRV = service_dist{i};
    Wait_record(:,:,i) = Q_GGsK_FIFO_NS(SimPra, QueuePra);
end
% toc

a = Wait_record(:,1,:) .* Wait_record(:,2,:);
b = sum(a,3);
c = b ./ sum(Wait_record(:,2,:),3);

c = c*60;  % unit from hour to min

aveWait = mean(c);            
aveWait_var = var(c)/simR;    

end