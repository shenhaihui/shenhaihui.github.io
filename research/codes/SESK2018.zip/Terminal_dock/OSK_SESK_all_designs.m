clear; clc; close all;
addpath ../SKDec122009/SK_code_version1_1229;
addpath ..


%%% Predicted points
M = 111; x1L = 5; x2L = 61; x3L = 5; x4L = 21;
% the entire 8855 points in the feasible region are considered
i = 0;
XK = zeros(8855,4);
y_true = zeros(8855,1);
for x1 = x1L : M-x2L-x3L-x4L
    for x2 = x2L : M-x1-x3L-x4L
        for x3 = x3L : M-x1-x2-x4L
            for x4 = x4L : M-x1-x2-x3
                i = i+1;
                x = [x1 x2 x3 x4];               
                XK(i,:) = x;
            end
        end
    end
end
K = size(XK,1);

% load the "true" response value
% to see how it is obtained, see Generate_True_Waiting_Time.m
load('y_true.mat');

% calculate the response value in the stylized models
refK1 = zeros(K,1);
refK2 = zeros(K,1);
for i=1:K
    x = XK(i,:);
    refK1(i) = stylized1(x);
    % average run time: 0.002s on MATLAB R2015a    
    refK2(i) = stylized2(x);
    % average run time: 0.003s on MATLAB R2015a
    % Windows 7 Enterprise 64-bit Operating System
    % Interl Core i7-3770 CPU @ 3.40GHz, 8 GB RAM       
end  


%%% Observed points
% load the 40 set of design points (each contains 40 points), and the noisy
% observations.
% to see how it is obtained, see Generate_Design_Points_and_Obs.m
load('X_best40.mat');
load('Y_Vhat40.mat');

% calculate the RMSE and MAPE for the 40 sets of designs
RMSE = zeros(40,4);
MAPE = zeros(40,4);
for seti = 1:40  
    fprintf('Design points set: %d  \n',seti);
    X = X_best40(:,:,seti);   
    k = size(X,1);
    Y = Y40(:,:,seti);   
    Vhat = Vhat40(:,:,seti);       

    % calculate the response value in the stylized models
    ref1 = zeros(k,1);
    ref2 = zeros(k,1);
    for i=1:k
        x = X(i,:);
        ref1(i) = stylized1(x);
        % average run time: 0.002s on MATLAB R2015a    
        ref2(i) = stylized2(x);
        % average run time: 0.003s on MATLAB R2015a
        % Windows 7 Enterprise 64-bit Operating System
        % Interl Core i7-3770 CPU @ 3.40GHz, 8 GB RAM          
    end   
       
    %%% OSK
    BK = ones(K,1);
    B = ones(k,1);    
    skriging_model = SKfit(X,Y,B,Vhat,2);
    SK = SKpredict(skriging_model,XK,BK);   
    RMSE0 = sqrt(sum((SK - y_true).^2)/length(y_true));         % RMSE
    MAPE0 = sum(abs((SK - y_true) ./ y_true))/length(y_true);   % MAPE
    
    
    %%% SESK with stylized model 1
    BK = [ones(K,1) refK1];
    B = [ones(k,1) ref1];
    skriging_model = SKfit(X,Y,B,Vhat,2);
    SK = SKpredict(skriging_model,XK,BK);
    RMSE1 = sqrt(sum((SK - y_true).^2)/length(y_true));
    MAPE1 = sum(abs((SK - y_true) ./ y_true))/length(y_true);
    
    %%% SESK with stylized model 2
    BK = [ones(K,1) refK2];
    B = [ones(k,1) ref2];    
    skriging_model = SKfit(X,Y,B,Vhat,2);
    SK = SKpredict(skriging_model,XK,BK);
    RMSE2 = sqrt(sum((SK - y_true).^2)/length(y_true));
    MAPE2 = sum(abs((SK - y_true) ./ y_true))/length(y_true);
    
    %%% SESK with stylized model 1 & 2
    BK = [ones(K,1) refK1, refK2];
    B = [ones(k,1) ref1, ref2];
    skriging_model = SKfit(X,Y,B,Vhat,2);
    SK = SKpredict(skriging_model,XK,BK);
    RMSE3 = sqrt(sum((SK - y_true).^2)/length(y_true));
    MAPE3 = sum(abs((SK - y_true) ./ y_true))/length(y_true);
    
    RMSE(seti, :) = [RMSE0 RMSE1 RMSE2 RMSE3];
    MAPE(seti, :) = [MAPE0 MAPE1 MAPE2 MAPE3];
end

fprintf('OSK RMSE [min, max, mean, median] = [%.3f, %.3f, %.3f, %.3f] \n', min(RMSE(:,1)), max(RMSE(:,1)), mean(RMSE(:,1)), median(RMSE(:,1)));
fprintf('OSK MAPE [min, max, mean, median] = [%.5f, %.5f, %.5f, %.5f] \n', min(MAPE(:,1)), max(MAPE(:,1)), mean(MAPE(:,1)), median(MAPE(:,1)));
fprintf('SESK (stylized model 1) RMSE [min, max, mean, median] = [%.3f, %.3f, %.3f, %.3f] \n', min(RMSE(:,2)), max(RMSE(:,2)), mean(RMSE(:,2)), median(RMSE(:,2)));
fprintf('SESK (stylized model 1) MAPE [min, max, mean, median] = [%.5f, %.5f, %.5f, %.5f] \n', min(MAPE(:,2)), max(MAPE(:,2)), mean(MAPE(:,2)), median(MAPE(:,2)));
fprintf('SESK (stylized model 2) RMSE [min, max, mean, median] = [%.3f, %.3f, %.3f, %.3f] \n', min(RMSE(:,3)), max(RMSE(:,3)), mean(RMSE(:,3)), median(RMSE(:,3)));
fprintf('SESK (stylized model 2) MAPE [min, max, mean, median] = [%.5f, %.5f, %.5f, %.5f] \n', min(MAPE(:,3)), max(MAPE(:,3)), mean(MAPE(:,3)), median(MAPE(:,3)));
fprintf('SESK (stylized model 1&2) RMSE [min, max, mean, median] = [%.3f, %.3f, %.3f, %.3f] \n', min(RMSE(:,4)), max(RMSE(:,4)), mean(RMSE(:,4)), median(RMSE(:,4)));
fprintf('SESK (stylized model 1&2) MAPE [min, max, mean, median] = [%.5f, %.5f, %.5f, %.5f] \n', min(MAPE(:,4)), max(MAPE(:,4)), mean(MAPE(:,4)), median(MAPE(:,4)));

