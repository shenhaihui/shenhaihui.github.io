function [f, MSE] = SKGpredict(model,Xpred,Bpred)
% make predictions at prediction points using a stochastic kriging model  
% model = output of GESKfit
% Xpred = (K x d) matrix of prediction points
% Bpred = (K x b) matrix of basis functions at each prediction point
%         The first column must be a column of ones!
% f = (K x 1) predictions at predictions points

% retrieve model parameters from model structure obtained from SKfit
X = model.X;
[k, d] = size(X);

tau2 = model.tausquared;
theta = model.theta;
beta = model.beta;

A = model.A;
B = model.B;
YD = model.YD;

K = size(Xpred,1);     % number of prediction points

% Note: for kriging with gradient, normalization is NOT applicable!

% covariance vector, for each x0
% correlation function: exponential
gammapred = zeros(k*(d+1),K);
for j = 1 : K
    x0 = Xpred(j,:);
    for i = 0 : d
        for ii = 1 : k
            rown = i * k + ii;
            if i == 0
                gammapred(rown,j) = C(x0,X(ii,:),tau2,theta);
            else
                gammapred(rown,j) = 2*theta(i)*(x0(i)-X(ii,i)) * C(x0,X(ii,:),tau2,theta);
            end        
        end
    end
end

% calculate responses at prediction points 
f = Bpred*beta + gammapred'/A*(YD-B*beta);

% calculate MSE
if nargout > 1        
    MSE = zeros(K,1);
    for i = 1 : K
        r = gammapred(:,i);      
        delta = Bpred(i,:)' - B'/A*r;    
        MSE(i,1) = tau2 - r'/A*r + delta'*(B'/A*B)^(-1)*delta;      
    end
end

end


function C00 = C(x1,x2,tau2,theta)
% correlation for response surface
% correlation function: exponential
C00 = tau2 * exp(- (x1 - x2).^2 * theta);
end