clear; clc; close all;
addpath ../SKDec122009/SK_code_version1_1229;
addpath ..

% queue length of M/G/1 (excluding the customer in service)
% arrival rate is x
% service time ~ gamma dist with shape 1/2 and rate 1/2.

kriging_type = 0;
% 0, Ordinary Stochastic Kriging (OSK)
% 1, Stylized-Model Enhanced Stochastic Kriging (SESK) with M/M/1
% 2, SESK with rougher stylized model
% 3, SESK with irrelevant stylized model

%%% Predicted points
XK = (0.01:0.01:0.99)';

% the true curve
y_true = 1.5 * XK.^2 ./ (1-XK);

%%% Observed points
X = [0.2; 0.4; 0.6; 0.8];
% true value
Y = 1.5 * X.^2 ./ (1-X);
% add artificial noise
% for reproducibility, arbitrarily fix a random seed
s = RandStream('mt19937ar','Seed',22);
RandStream.setGlobalStream(s);


T = 2500; N = 20;
noise_var = 1/4 * X.*(20+121*X-116*X.^2+29*X.^3) ./ (1-X).^4 /T;

noise = randn(length(X),N);
for i=1:length(X)
    noise(i,:) = noise(i,:) * sqrt(noise_var(i));   
end
Y = Y + mean(noise,2);

% variance vector (simulation noise) - (Independent, i.e., No CRN)
Vhat = var(noise')' / N; % use sample variance / N


switch (kriging_type)
    case 0 % OSK, constant trend term
        B = ones(size(X));
        BK = ones(size(XK));        
    case 1 % SESK with M/M/1
        ref = X.^2 ./ (1-X);
        refK = XK.^2 ./ (1-XK);       
        B = [ones(size(X)) ref];
        BK = [ones(size(XK)) refK];
    case 2 % SESK with rougher stylized model        
        ref = 3*(X).^9; 
        refK = 3*(XK).^9;
        B = [ones(size(X)) ref];
        BK = [ones(size(XK)) refK];        
    case 3 % SESK with irrelevant stylized model
        ref = 10*(X-0.52).^2;
        refK = 10*(XK-0.52).^2;        
        B = [ones(size(X)) ref];
        BK = [ones(size(XK)) refK];
end


% === >>> SK fit and predict:
% stochastic kriging with constant trend (q=0), 
% gammaP correlation function, 1-exponential, 2-gauss, 3-cubic
gammaP = 2;
skriging_model = SKfit(X,Y,B,Vhat,gammaP);
[SK_gau, MSE] = SKpredict(skriging_model,XK,BK);


% === >>> print parameters:
printSK (skriging_model);


% === >>> plot SK fitted surface:
figure;
set (gcf,'Position',[500,500,520,300])
plot(XK,y_true,'-','LineWidth',1,'Color',[31,119,180]/255); hold on;
plot(X,Y,'o','Color',[255,127,14]/255);
plot(XK,SK_gau,'k--','LineWidth',1);
% MSE
plot(XK,SK_gau+1.96*sqrt(MSE),':','LineWidth',0.8,'Color',[214,39,40]/255);
h1 = plot(XK,SK_gau-1.96*sqrt(MSE),':','LineWidth',0.8,'Color',[214,39,40]/255); 

% add ref
if kriging_type > 0
    plot(XK,refK,'-.','Color',[44,160,44]/255);
end

% figure format
axis([0 1 -1 11]);
xlabel('Arrival rate $x$','Interpreter','latex');
ylabel('Expected queue length','Interpreter','latex');
set(gca,'YTick',[0 2 4 6 8 10])

set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
switch (kriging_type)
    case 0 % OSK, constant trend term
        ht = legend({'True surface','Mean simulation output',...
            'Fitted surface of OSK','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
            },'Location','northwest');
    case 1 % SESK with M/M/1
        ht = legend({'True surface','Mean simulation output',...
            'Fitted surface of SESK','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
            'Stylized model (i) - $M/M/1$'},'Location','northwest');
    case 2 % SESK with rougher stylized model
        ht = legend({'True surface','Mean simulation output',...
            'Fitted surface of SESK','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
            'Stylized model (ii) - rougher'},'Location','northwest');           
    case 3 % SESK with irrelevant stylized model
        ht = legend({'True surface','Mean simulation output',...
            'Fitted surface of SESK','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
            'Stylized model (iii) - irrelevant'},'Location','northwest');       
end
set(ht,'Interpreter','latex','color','none'); % 'FontSize',10


% %%% save data, plot in python
% MSE_po = SK_gau+1.96*real(sqrt(MSE));
% MSE_ne = SK_gau-1.96*real(sqrt(MSE));
% save('MG1_plot_1.mat','XK','y_true','X','Y','SK_gau','MSE_po','MSE_ne');
% save('MG1_plot_4.mat','XK','y_true','X','Y','SK_gau','MSE_po','MSE_ne','refK');