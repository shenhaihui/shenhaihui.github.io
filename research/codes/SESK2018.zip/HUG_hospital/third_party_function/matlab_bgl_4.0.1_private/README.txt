These functions are part of the graph package MatlabBGL written by David Gleich.
http://dgleich.github.io/matlab-bgl
https://github.com/dgleich/matlab-bgl/

License: BSD
