%%%%%% This script generates the "true" sojourn time through sufficiently longtime simulation
%%%%%% 95% conffidence interval width < 0.1 hour

clear,clc

% The evaluation points (totally 1152 points)
x1 = [3 5];
x2 = [3 13];
x3 = [3 7];
x4 = [8 18 28];
x5 = [8 18 28];
x6 = [3 5];
x7 = [3 5];
x8 = [5 15];
x9 = [3 9];
[X1,X2,X3,X4,X5,X6,X7,X8,X9] = ndgrid(x1,x2,x3,x4,x5,x6,x7,x8,x9);
XX = [X1(:) X2(:) X3(:) X4(:) X5(:) X6(:) X7(:) X8(:) X9(:)];


y_true = zeros(size(XX,1),1);
for i = 1:size(XX,1)  
    tic
    fprintf('%d  \n',i);
    s = XX(i,:);   
    setting.simR = 50;
    setting.T0 = 10000;
    setting.T = 50000;
    SimT_var = HUG (s,setting,0);   
    y_true(i,1) = SimT_var(1,10);
    toc
end

