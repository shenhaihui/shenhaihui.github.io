# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator

#### Problem 3(1) - Method 1
np.random.seed(0) # set random seed
x = np.random.rand(2000,2) # generate 2000x2 uniform(0,1) random numbers
x = -1 + 2*x # transform to uniform(-1,1) random numbers
y = x[:,0]**2 + x[:,1]**2
x = x[y<=1,:] # only keep those inside the unit disk
# plot
plt.figure() 
plt.plot(x[:,0], x[:,1], '.')
plt.xlabel('x')
plt.ylabel('y')
plt.axis('square')
x_major_locator=MultipleLocator(0.5)
y_major_locator=MultipleLocator(0.5)
ax=plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.show()  

#### Problem 3(1) - Method 2
np.random.seed(0) # set random seed
theta = np.random.rand(1500,1) # generate 1500 uniform(0,1) random numbers
theta = 2*np.pi*theta # transform to uniform(0,2pi) random numbers
x = np.zeros((1500,2))
x[:,0] = np.cos(theta)[:,0]
x[:,1] = np.sin(theta)[:,0]
# randomly project into the disk
u = np.random.rand(1500,1)
x[:,0] = u[:,0]**0.5*x[:,0]
x[:,1] = u[:,0]**0.5*x[:,1]
# plot
plt.figure() 
plt.plot(x[:,0], x[:,1], '.')
plt.xlabel('x')
plt.ylabel('y')
plt.axis('square')
x_major_locator=MultipleLocator(0.5)
y_major_locator=MultipleLocator(0.5)
ax=plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.show()

##############################################################################

#### Problem 3(2) - Method 1
np.random.seed(0) # set random seed
x = np.random.rand(800,2) # generate 800x2 uniform(0,1) random numbers
x = -1 + 2*x # transform to uniform(-1,1) random numbers
y = x[:,0]**2 + x[:,1]**2
x = x[y<=1,:] # only keep those inside the unit disk
# project onto circle
y = (x[:,0]**2 + x[:,1]**2)**0.5
x[:,0] =  x[:,0] / y
x[:,1] =  x[:,1] / y
# plot
plt.figure() 
plt.plot(x[:,0], x[:,1], '.')
plt.xlabel('x')
plt.ylabel('y')
plt.axis('square')
x_major_locator=MultipleLocator(0.5)
y_major_locator=MultipleLocator(0.5)
ax=plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.show()

#### Problem 3(2) - Method 2
np.random.seed(0) # set random seed
theta = np.random.rand(800,1) # generate 800 uniform(0,1) random numbers
theta = 2*np.pi*theta # transform to uniform(0,2pi) random numbers
x = np.zeros((800,2))
x[:,0] = np.cos(theta)[:,0]
x[:,1] = np.sin(theta)[:,0]
# plot
plt.figure() 
plt.plot(x[:,0], x[:,1], '.')
plt.xlabel('x')
plt.ylabel('y')
plt.axis('square')
x_major_locator=MultipleLocator(0.5)
y_major_locator=MultipleLocator(0.5)
ax=plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.show()

#### Problem 3(2) - Method 3
np.random.seed(0) # set random seed
x = np.random.normal(0,1,(800,2)) # generate 800x2 N(0,1) random numbers
# normalization
y = (x[:,0]**2 + x[:,1]**2)**0.5
x[:,0] =  x[:,0] / y
x[:,1] =  x[:,1] / y
# plot
plt.figure() 
plt.plot(x[:,0], x[:,1], '.')
plt.xlabel('x')
plt.ylabel('y')
plt.axis('square')
x_major_locator=MultipleLocator(0.5)
y_major_locator=MultipleLocator(0.5)
ax=plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.show()

##############################################################################

#### Problem 3(3) - Method 1
np.random.seed(0) # set random seed
x = np.random.rand(2000,3) # generate 2000x3 uniform(0,1) random numbers
x = -1 + 2*x # transform to uniform(-1,1) random numbers
y = x[:,0]**2 + x[:,1]**2 + x[:,2]**2
x = x[y<=1,:] # only keep those inside the unit ball
# plot
fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.scatter(x[:,0], x[:,1], x[:,2])
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
ax.set_box_aspect((1, 1, 1))
plt.show()  

#### Problem 3(3) - Method 2
np.random.seed(0) # set random seed
x = np.random.normal(0,1,(1000,3)) # generate 1000x3 N(0,1) random numbers
# normalization
y = (x[:,0]**2 + x[:,1]**2 + x[:,2]**2)**0.5
x[:,0] =  x[:,0] / y
x[:,1] =  x[:,1] / y
x[:,2] =  x[:,2] / y
# randomly project into the ball
u = np.random.rand(1000,1)
x[:,0] = u[:,0]**(1/3)*x[:,0]
x[:,1] = u[:,0]**(1/3)*x[:,1]
x[:,2] = u[:,0]**(1/3)*x[:,2]
# plot
fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.scatter(x[:,0], x[:,1], x[:,2])
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
ax.set_box_aspect((1, 1, 1))
plt.show()  

##############################################################################

#### Problem 3(4) - Method 1
np.random.seed(0) # set random seed
x = np.random.rand(1500,3) # generate 1500x3 uniform(0,1) random numbers
x = -1 + 2*x # transform to uniform(-1,1) random numbers
y = x[:,0]**2 + x[:,1]**2 + x[:,2]**2
x = x[y<=1,:] # only keep those inside the unit ball
# project onto sphere
y = (x[:,0]**2 + x[:,1]**2 + x[:,2]**2)**0.5
x[:,0] =  x[:,0] / y
x[:,1] =  x[:,1] / y
x[:,2] =  x[:,2] / y
# plot
fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.scatter(x[:,0], x[:,1], x[:,2])
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
ax.set_box_aspect((1, 1, 1))
plt.show()  

#### Problem 3(4) - Method 2
np.random.seed(0) # set random seed
u = np.random.rand(800,2) # generate 800x3 uniform(0,1) random numbers
theta = 2*np.pi*u[:,0] # transform to uniform(0,2pi) random numbers
v = -1 + 2*u[:,1] # transform to uniform(-1,1) random numbers
phi = np.arccos(v)
x = np.zeros((800,3))
x[:,0] = np.sin(phi) * np.cos(theta)
x[:,1] = np.sin(phi) * np.sin(theta)
x[:,2] = v
# plot
fig = plt.figure()
ax = fig.add_subplot(projection='3d')
# ax.scatter(x[:,0], x[:,1], x[:,2], s=5)
ax.scatter(x[:,0], x[:,1], x[:,2])
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
ax.set_box_aspect((1, 1, 1))
plt.show()  

#### Problem 3(4) - Method 3
np.random.seed(0) # set random seed
x = np.random.normal(0,1,(800,3)) # generate 800x3 N(0,1) random numbers
# normalization
y = (x[:,0]**2 + x[:,1]**2 + x[:,2]**2)**0.5
x[:,0] =  x[:,0] / y
x[:,1] =  x[:,1] / y
x[:,2] =  x[:,2] / y
# plot
fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.scatter(x[:,0], x[:,1], x[:,2])
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
ax.set_box_aspect((1, 1, 1))
plt.show()  